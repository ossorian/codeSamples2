<?php

namespace Ac\Forms\Forms\Structure;

use Ac\Forms\Forms\Data\Sync\StructureSync;
use Generator;

/**
 * Class ReferenceParser
 * @package Ac\Forms\Forms\Structure
 *
 * Рекурсивный перебор структуры формы, поиск по коду, передаваемому в генераторе getNext,
 * Найденный блок передаётся в виде объекта ReferenceParserBlock с двумя переменными, с текущими дангными и текущими дангными по ссылке.
 * С первой переменной можно сверять условия, вторую можно видоизменять. При этом будет сразу меняться головная структура.
 * Переменная $currentDataReference устарела, и нужна только для совместимости в методе getNextBlockHaving, если возвращается только значение
 * После всех изменений получить новые данные через getData(), но также все изменения сразу находятся в исходной переменной, передаваемой в конструктор
 */
class ReferenceParser
{
    public ?array $currentDataReference = [];
    public bool $searchAsElementId = false;
    protected array $proceedFields = StructureSync::TREE_PROCEED_FIELDS;
    protected array $data;
    protected ?array $previousParseData = null;
    
    public function __construct(array &$data, $excludeFields = [])
    {
        $this->data = &$data;
        array_push($this->proceedFields, 'structure', 'value');
        if ($excludeFields) {
            $this->proceedFields = array_diff($this->proceedFields, $excludeFields);
        }
    }
    
    /**
     * Получаем все блоки с кодом $findCode
     * @param string $findCode
     * @param array|null $parseData
     * @return Generator
     */
    public function getNext(string $findCode, ?array &$parseData = null): Generator
    {
        if (is_null($parseData)) {
            $this->previousParseData = null;
            $parseData = &$this->data;
        }
        
        if ((!$this->searchAsElementId && ($parseData['code'] === $findCode))
        || ($parseData['elementId'] == $findCode)) {
            yield new ReferenceParserBlock($parseData, $this->previousParseData);
        }
    
        if (!isset($parseData[0])) {
            $this->previousParseData = $parseData;
        }
        foreach ($parseData as $datumKey => &$datum) {
            if (is_array($datum) && (is_numeric($datumKey) || in_array($datumKey, $this->proceedFields))) {
                yield from $this->getNext($findCode, $datum);
            }
        }
    }

    public function getNextByType(string $findType, ?array &$parseData = null): Generator
    {
        if (is_null($parseData)) {
            $this->previousParseData = null;
            $parseData = &$this->data;
        }

        if (!$this->searchAsElementId && $parseData['type'] === $findType) {
            yield new ReferenceParserBlock($parseData, $this->previousParseData);
        }

        if (!isset($parseData[0])) {
            $this->previousParseData = $parseData;
        }
        foreach ($parseData as $datumKey => &$datum) {
            if (is_array($datum) && (is_numeric($datumKey) || in_array($datumKey, $this->proceedFields))) {
                yield from $this->getNextByType($findType, $datum);
            }
        }
    }
    
    public function getOne(string $findCode): ?ReferenceParserBlock
    {
        foreach ($this->getNext($findCode) as $block) {
            return $block;
        }
        return null;
    }
    
    /* Вспомогательный метод */
    public function getCodes(): array
    {
        $codeResults = [];
        foreach ($this->getNextBlockHaving('code', true) as $code) {
            if ($code) {
                $codeResults[] = $code;
            }
        }
        return $codeResults;
    }
    
    /**
     * Получаем все блоки с наличием поля $findField
     * @param string $findField
     * @param bool $valueOnly
     * @param array|null $parseData
     * @return Generator
     */
    public function getNextBlockHaving(string $findField, bool $valueOnly = true, ?array &$parseData = null): Generator
    {
        if (is_null($parseData)) {
            $this->previousParseData = null;
            $parseData = &$this->data;
        }
        
        if (isset($parseData[$findField])) {
            $this->currentDataReference = &$parseData;
            if ($valueOnly) {
                yield $parseData[$findField];
            } else {
                yield new ReferenceParserBlock($parseData, $this->previousParseData);
            }
        }
    
        if (!isset($parseData[0])) {
            $this->previousParseData = $parseData;
        }
        foreach ($parseData as $datumKey => &$datum) {
            if (is_array($datum) && (is_numeric($datumKey) || in_array($datumKey, $this->proceedFields))) {
                yield from $this->getNextBlockHaving($findField, $valueOnly, $datum);
            }
        }
    }
    
    /**
     * Получаем все блоки, не имеющие поля $findField
     * @param string $findField
     * @param array|null $parseData
     * @return Generator
     */
    public function getNextBlockNotHaving(string $findField, $findEmpty = true, ?array &$parseData = null): Generator
    {
        if (is_null($parseData)) {
            $this->previousParseData = null;
            $parseData = &$this->data;
        }
    
        if (empty($parseData[$findField])) {
            if ($findEmpty || !isset($parseData[$findField])) {
                yield new ReferenceParserBlock($parseData, $this->previousParseData);
            }
        }
    
        if (!isset($parseData[0])) {
            $this->previousParseData = $parseData;
        }
        foreach ($parseData as $datumKey => &$datum) {
            if (is_array($datum) && (is_numeric($datumKey) || in_array($datumKey, $this->proceedFields))) {
                yield from $this->getNextBlockNotHaving($findField, $findEmpty, $datum);
            }
        }
    }

    public function getData(): array
    {
        return $this->data;
    }
    
    public function addProceedField(string $proceedField): void
    {
        $this->proceedFields[] = $proceedField;
    }
}