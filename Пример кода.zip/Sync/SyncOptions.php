<?php

namespace Ac\Forms\Forms\Data\Sync;

use Ac\Forms\Forms\Inspector\SectionHandler;

/**
 * Class SyncOptions - общие настройки при синхронизации
 * @package Ac\Forms\Forms\Data\Sync
 */
final class SyncOptions
{
    public array $deleted = [];
    public array $updated = [];
    public array $created = [];
    public array $resorted = [];
    public bool $isAnyChange = false;
    public bool $isUseEmptySchema = false;
    public bool $syncAllways = false;
    public array $syncElementIds = [];
    public array $structure;
    
    //Опциональные параметры
    public array $noupdatedFields = [];
    
    public function __construct(array $schemaData, $syncAllways = false)
    {
        $this->syncAllways = $syncAllways;
        if (isset($schemaData['structure'])) {
            $this->structure = $schemaData['structure'];
            $this->deleted = $schemaData['elements_id_removed'] ? array_unique($schemaData['elements_id_removed']) : [];
            $this->updated = $schemaData['elements_id_updated'] ? array_unique($schemaData['elements_id_updated']) : [];
            $this->created = $schemaData['elements_id_added'] ? array_unique($schemaData['elements_id_added']) : [];
            $this->resorted = $schemaData['updatedFieldIndexElementIds'] ? array_unique($schemaData['updatedFieldIndexElementIds']) : [];
            $this->isAnyChange = $this->deleted || $this->updated || $this->created || $this->resorted;
            $this->isUseEmptySchema = $this->updated || $this->created || $this->resorted;
        } else {
            $this->structure = $schemaData;
        }
    }
    
    public static function getInstanceByFormAndSection(int $formId, string $sectionCode): self
    {
        $schemaData = SectionHandler::getStructure($formId, $sectionCode);
        return new self($schemaData);
    }
    
    public function showOptions(): void
    {
        foreach ($this as $property => $value) {
            if (!is_array($this->$property) || ($property === 'structure')) {
                continue;
            }
            echo "$property => " . implode(', ', $value) . '<br>';
        }
    }
}