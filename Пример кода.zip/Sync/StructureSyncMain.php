<?php

namespace Ac\Forms\Forms\Data\Sync;

use Ac\Forms\Exception\SyncErrorException;
use Ac\Forms\Forms\Data\MainData;
use Ac\Forms\Forms\Inspector\FormHandler;
use Ac\Forms\Forms\Inspector\SectionHandler;
use Bitrix\Iblock\ElementTable;

/**
 * Class StructureSyncMain - запускает синхронизацию, находит нужные точки для изменения в структуре с данными и производит эти изменения на основе данных ,полученных из StructureSync
 * @package Ac\Forms\Forms\Data\Sync
 */
final class StructureSyncMain
{
    public StructureSync $structureSync;
    public int $formId;
    public string $sectionCode;
    
    public string $error = '';
    public string $notice = '';
    
    protected ?SyncOptions $syncOptions;
    
    //Массив элементов которые можно парсить, иначе будут парситься все, задаётся при создании объекта.
    private array $syncElementIds;
    
    //Текущий блок синхронизации
    private int $currentFormElementId;
    
    private bool $saveLog = false;
    private int $logFormElementId;
    private string $logMainpath;
    private int $maxDaysLogSave = 15;
    
    public function __construct(int $formId, string $sectionCode, array $newStructure = [], array $syncElementIds = [], ?SyncOptions $options = null)
    {
        $this->formId = $formId;
        $this->sectionCode = $sectionCode;
        
        if (empty($options)) {
            //TODO: проверить нужен ли в рабочем состоянии первый вариант.
            //Пустой вариант для тестирования, использует уже сохраненную пустую структуру
            if (empty($newStructure)) {
                $options = SyncOptions::getInstanceByFormAndSection($formId, $sectionCode);
            } else {
                $options = new SyncOptions($newStructure);
            }
        }
        
        $this->syncOptions = $options;
        
        if ($options->syncElementIds = $this->syncElementIds = $this->getAllElements($syncElementIds)) {
            $this->structureSync = new StructureSync($formId, $sectionCode, $options);
        }
        
        $this->prepareLog();
        $this->logMessage('Добавление', true);
        $this->logMessage(print_r($this->structureSync->emptyCreateSchemaParts, true));
        //$this->showOptions();
    }
    
    public static function sync(int $formId, string $sectionCode, array $newStructure = [], array $elementIds = [], ?SyncOptions $syncOptions = null): bool
    {
        if (empty($newStructure) && (!$newStructure = SectionHandler::getStructure($formId, $sectionCode))) {
            return false;
        }
        return (new self($formId, $sectionCode, $newStructure, $elementIds, $syncOptions))->doSync();
    }
    
    public static function resync(int $formId, string $sectionCode): bool
    {
        return self::sync($formId, $sectionCode, []);
    }
    
    public function customSync(callable $method): void
    {
        foreach ($this->structureSync->changedElementSectionData as $currentFormElementId => &$structure) {
            if ($structure && $method($structure)) {
                $this->structureSync->isFormElementChanged[$currentFormElementId] = true;
            }
        }
        $this->structureSync->save();
    }
    
    public function showOptions(): void
    {
        $this->structureSync->options->showOptions();
    }
    
    private function getAllElements(array $filterElementsId = []): array
    {
        if (!$iblockId = FormHandler::getIblockIdByFormId($this->formId)) {
            $this->error = "Не найден инфоблок для синхронизации";
            return [];
        }
        
        $arFilter = ['ACTIVE' => 'Y', 'IBLOCK_ID' => $iblockId];
        if ($filterElementsId) {
            $arFilter['ID'] = $filterElementsId;
        }
        
        $result = ElementTable::getList([
            'filter' => $arFilter,
            'select' => ['ID']
        ])->fetchAll();

        if (!$elementsId = array_column($result, 'ID') ?: []) {
            $this->notice = 'Не найдены элементы для синхронизации';
        }
        
        return $elementsId ?: [];
    }
    
    public function doSync(): bool
    {
        //Отсутствие объекта синхронизации означает отсутствие элементов формы для синхронизации
        if (empty($this->structureSync)) {
            return true;
        }
        
        foreach ($this->structureSync->changedElementSectionData as $this->currentFormElementId => &$structure) {
            if (($this->syncElementIds && !in_array($this->currentFormElementId, $this->syncElementIds))
                || empty($structure)
            ) {
                continue;
            }
            
            $firstParent = [];
            $this->parseRecursive($structure, $firstParent, 0);
    
            if ($this->structureSync->emptyCreateBlocksSchemaParts) {
                array_push($structure, ...$this->structureSync->emptyCreateBlocksSchemaParts);
                $this->setChanged('Created', 0);
            }
        }
        unset($structure);
    
        if (!$result = $this->structureSync->save()) {
            $this->logMessage($this->structureSync->error);
        }
        
        return $result;
    }
    
    /**
     * @deprecated
     * @param int $formElementId
     * @return bool
     * @throws \Bitrix\Main\ArgumentException
     * @throws \Bitrix\Main\ObjectPropertyException
     * @throws \Bitrix\Main\SystemException
     */
    private function copyStructure(int $formElementId): bool
    {
        return MainData::saveFullFormSectionElementData(
            $this->structureSync->formId,
            $this->structureSync->sectionCode,
            $formElementId,
            $this->structureSync->options->structure,
            $forceCopy = true
        );
    }
    
    /**
     * Парсинг структуры с данными и замена/удаление/добавление
     * @param array $parseData
     * @param $parentData
     * @param $parentKey
     */
    private function parseRecursive(array &$parseData, &$parentData, $parentKey): void
    {
        if ($elementId = (int)$parseData['elementId']) {
            
            //Блокировка дублирования создания основных блоков в случае перезапуска синхронизации
            if (isset($this->structureSync->emptyCreateBlocksSchemaParts[$elementId])) {
                unset($this->structureSync->emptyCreateBlocksSchemaParts[$elementId]);
            }
            
            if ($this->syncDeleted($elementId, $parentData, $parentKey)) {
                return;
            }
    
            //Сперва нужно внести изменения, потом уже добавлять новое, обязательно в этом порядке
            $skipFlag = false;//Используется в особых случаях, когда нельзя продолжать парсить или добавлять
            $this->syncUpdated($elementId, $parseData, $skipFlag);
            if ($skipFlag) {
                return;
            }
            $this->syncResorted($elementId, $parseData);
        }
        
        $parentData = &$parseData;
        foreach ($parseData as $dataParentKey => &$datum) {
            if (is_array($datum)) {
                $this->parseRecursive($datum, $parentData, $dataParentKey);
            }
        }
        unset($datum);
        
        if ($elementId) {
            $this->syncCreated($elementId, $parseData);
        }
    }
    
    //Удаляется элемент массива родителя, которым и является текущий удаляемый элемент
    private function syncDeleted(int $elementId, &$parentData, $parentKey): bool
    {
        if (in_array($elementId, $this->structureSync->options->deleted)
            && is_array($parentData)
            && isset($parentData[$parentKey])
        ) {
            unset($parentData[$parentKey]);
            if ($this->checkNumericKeys($parentData)) {
                $parentData = array_values($parentData);
            }
            $this->setChanged('Deleted', $elementId);
            return true;
        }
        return false;
    }
    
    //TODO: Продумать как оставлять value для некоторых полей
    //Заменяем текущиий элемент, но кроме полей данных, указанных в \Ac\Forms\Forms\Data\Sync\StructureSync::UPDATE_UNSET_FIELDS
    private function syncUpdated(int $elementId, &$currentData, bool &$skipFlag): void
    {
        if (in_array($elementId, $this->structureSync->options->updated) && is_array($newData = $this->structureSync->emptyUpdateSchemaParts[$elementId])) {
    
            //Специальные условия множественности
            //Переход с единичного поля на множественный
            if (!$currentData['multiple'] && $newData['multiple']) {
                $currentData['fields'] = [];
                //fieldDefault при смене режима апдейтится целиком, как добавление
                $skipFlag = true;
            }
            //Переход с множественного поля на единичный
            if ($currentData['multiple'] && !$newData['multiple']) {
                $currentData['fieldDefault'] = null;
                //При переходе fields обнуляется, но они будут заново создаваться через creator, т.к. поле fields входит в общий список полей, по которому парсится дерево.
                $currentData['fields'] = [];
                $skipFlag = false;
            }
            //Поле fieldDefault нельзя изначально вставить в \Ac\Forms\Forms\Data\Sync\StructureSync::UPDATE_UNSET_FIELDS, т.к. поле multiple меняется
            //Но оно обновляется согласно общим законам и \Ac\Forms\Forms\Data\Sync\StructureSync::TREE_PROCEED_FIELDS
            if ($currentData['multiple'] && $newData['multiple']) {
                unset($newData['fieldDefault']);
            }

            //Сохранение значений данных при смене параметров элемента
            if (array_key_exists('value', $currentData) && array_key_exists('value', $newData)) {
                //Сохранение значений данных при смене параметров элемента
                if (!is_array($currentData['value']) || isset($currentData['value']['id'])) {
                    unset($newData['value']);
                }
                
                //Затирание значения элемента при смене типа элемента
                if ($currentData['type'] != $newData['type']) {
                    $newData['value'] = '';
                }
            }
            
            //Удаление отдельных полей и синхронизируемых элементов
            if ($this->syncOptions->noupdatedFields) {
                foreach ($this->syncOptions->noupdatedFields as $field) {
                    if (isset($newData[$field])) {
                        unset($newData[$field]);
                    }
                }
            }
            
            $currentData = array_merge($currentData, $newData);
            $this->setChanged('Updated', $elementId);
        }
    }
    
    //Пересортирует поля в свойстве fields, если это было сделано в конструкторе
    public function syncResorted(int $elementId, &$parseData): void
    {
        if ((!$currentResortOrder = $this->structureSync->resortedSchemaParts[$elementId])
            || empty($parseData['fields'])
            || (sizeof($parseData['fields']) < 2)
        ) {
            return;
        }
        
        //Сбор текущих полей
        $currentSchema = [];
        foreach ($parseData['fields'] as $field) {
            if (!$fieldElementId = (int)$field['elementId']) {
                throw new SyncErrorException('Поле не обладает параметром elementId, скорее всего раздел создавался не через конструктор!');
            }
            $currentSchema[$fieldElementId] = $field;
        }
        
        //Пересортировка
        $resortedFields = [];
        foreach ($currentResortOrder as $resortedElementId) {
            if (!$currentSchema[$resortedElementId]) {
                throw new SyncErrorException('При пересортировке в элементе ' . $elementId . ' отсутствует поле с elementId ' . $resortedElementId);
            }
            $resortedFields[] = $currentSchema[$resortedElementId];
        }
        
        if (sizeof($resortedFields) !== sizeof($currentResortOrder)) {
            throw new SyncErrorException('Количество пересортируемых полей не соответствует в ' . $elementId);
        }
        $parseData['fields'] = $resortedFields;
        
        $this->setChanged('Resorted', $elementId);
    }
    
    //Добавляем ранее найденные значения в ранее определённый родительский элемент
    private function syncCreated(int $elementId, &$parseData): void
    {
        if (!empty($createData = $this->structureSync->emptyCreateSchemaParts[$elementId])) {
            foreach ($createData as $field => $values) {
                if (empty($parseData[$field])) {
                    $parseData[$field] = [];
                }
                if (is_array($parseData[$field]) && is_array($values) && !empty($values)) {
                    $values = $this->filterCreatingDuplicates($parseData[$field], $values);
                    if ($values) {
                        array_push($parseData[$field], ...$values);
                    }
                }
                $this->setChanged('Created', $elementId);
            }
        }
    }
    
    /**
     * Отфильтровывает дублирующие элементы при добавлении
     * @param $currentValues
     * @param $newValues
     * @return array
     */
    private function filterCreatingDuplicates($currentValues, $newValues): array
    {
        $currentElementIds = array_column($currentValues, 'elementId');
        foreach ($newValues as $key => $newValue) {
            if (($elementId = $newValue['elementId']) && (in_array($elementId, $currentElementIds))) {
                unset($newValues[$key]);
            }
        }
        return $newValues;
    }
    
    private function setChanged(string $type, int $elementId): void
    {
        $this->structureSync->isFormElementChanged[$this->currentFormElementId] = true;
        $varname = 'formElementParts' . $type;
        $this->structureSync->$varname[] = $this->currentFormElementId;
        $this->log($type, $elementId);
    }
    
    /** Логирование
     * @param string $type
     * @param int $elementId
     */
    private function log(string $type, int $elementId)
    {
        if ($this->saveLog) {
            if (empty($this->logFormElementId) || ($this->logFormElementId !== $this->currentFormElementId)) {
                $this->logMessage("Изменения для элемента формы " . $this->currentFormElementId, true);
                $this->logFormElementId = $this->currentFormElementId;
            }
            
            switch($type) {
                case 'Deleted' : $text = "Удалён блок $elementId"; break;
                case 'Updated' : $text = "Изменён блок $elementId"; break;
                case 'Created' : $text = "В блок $elementId добавлены новые поля"; break;
                case 'Resorted' : $text = "В блоке $elementId пересортированы поля"; break;
            }
            $this->logMessage($text);
        }
    }
    
    private function logMessage($text, $addRowBefore = true): void
    {
        if ($this->saveLog) {
            $filepath = $this->logMainpath . date('Y-m-d') . '.txt';
            file_put_contents($filepath, ($addRowBefore ? PHP_EOL : '') . date('H:i:s: ') . $text . PHP_EOL, FILE_APPEND);
        }
    }
    
    private function cleanUpLog(): void
    {
        $now = time();
        $files = glob($this->logMainpath . '*.txt');
        foreach ($files as $filename) {
            if (($now - filemtime($filename)) > ($this->maxDaysLogSave * 86400)) {
                unlink($filename);
            }
        }
    }
    
    private function prepareLog(): void
    {
        if ($this->saveLog) {
            if (!file_exists($this->logMainpath = $_SERVER['DOCUMENT_ROOT'] . '/local/logs/sync/')) {
                mkdir($this->logMainpath, 0777, true);
            }
            $this->cleanUpLog();
        }
    }
    
    private function checkNumericKeys(array $parseData): bool
    {
        //\Bitrix\Main\Diag\Debug::writeToFile(array_keys($parseData), 'parseData', '/local/logs/tmp2.txt');
        return !empty($parseData) && is_numeric(implode('', array_keys($parseData)));
    }
}