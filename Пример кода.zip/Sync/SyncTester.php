<?php

namespace Ac\Forms\Forms\Data\Sync;

/**
 * Class SyncTester - для тестирования синхронизации
 * @package Ac\Forms\Forms\Data\Sync
 */
class SyncTester
{
    public static string $message = '';
    private static bool $foundElementId = false;
    private static int $findElementId = 0;
    
    private static bool $countElements = false;
    private static array $countElementsArray = [];
    private static array $changeVars = [
        'formElementPartsDeleted' => 'Удалены данные из элементов',
        'formElementPartsUpdated' => 'Изменены данные для элементов',
        'formElementPartsCreated' => 'Добавлены данные для элементов'
    ];
    
    public static function test(int $elementId = 0)
    {
        if (StructureSyncMain::sync(1, 'pervyy_razdel_pervoy_formy', [], $elementId ? [$elementId] : [])) {
            echo "Синхронизация прошла успешно<br>";
        } else {
            echo "Ошибка синхронизации<br>";
        }

        foreach (self::$changeVars as $objVar => $text) {
            if (StructureSyncMain::$currentObj->structureSync->$objVar) {
                echo $text . ' (' . implode(', ', StructureSyncMain::$currentObj->structureSync->$objVar) . ')<br>';
            }
        }
        StructureSyncMain::$currentObj->structureSync->options->showOptions();
    }
    
    public static function isElement(int $formId, string $sectionCode, int $elementId, int $formElementId = 0): bool
    {
        if (!$structure = self::getStructure($formId, $sectionCode, $formElementId)) {
            return false;
        }
        self::$findElementId = $elementId;
        self::parseRecursive($structure);
        return self::$foundElementId;
    }
    
    public static function countElements(int $formId, string $sectionCode, int $formElementId = 0): array
    {
        if (!$structure = self::getStructure($formId, $sectionCode, $formElementId)) {
            return false;
        }
        self::$countElements = true;
        self::parseRecursive($structure);
        return self::$countElementsArray;
    }
    
    public static function putJson(array $data, int $variant)
    {
        file_put_contents($_SERVER['DOCUMENT_ROOT'] . "/local/logs/sync/json" . $variant . ".txt", json_encode($data));
    }
    
    private static function getStructure(int $formId, string $sectionCode, int $formElementId = 0): array
    {
        self::resetParams();
        if ($formElementId) {
            $structure = \Ac\Forms\Forms\Data\MainData::getFullFormSectionElementData($formId, $formElementId, $sectionCode);
        } else {
            $structure = \Ac\Forms\Forms\Inspector\SectionHandler::getStructure($formId, $sectionCode);
        }
        if ($structure['elementsIdCounter'] === 0) {
            self::$message = "Получена пустая структура";
            return [];
        }
        return $structure;
    }
    
    private function parseRecursive(array $parseData): void
    {
        if (!empty($parseData['elementId']) && ($elementId = (int)$parseData['elementId'])) {
            if (self::$findElementId && ($elementId === self::$findElementId)) {
                self::$foundElementId = true;
            }
    
            if (self::$countElements) {
                self::$countElementsArray[$elementId]++;
            }
            
        }
    
        if (self::exitRecursiveStatement()) return;
        
        foreach ($parseData as $datum) {
            if (is_array($datum)) {
                self::parseRecursive($datum, $parentData, $dataParentKey);
            }
        }
    }
    
    private static function exitRecursiveStatement(): bool
    {
        if (!empty(self::$foundElementId)) {
            return true;
        }
        return false;
    }
    
    private static function resetParams()
    {
        self::$foundElementId = false;
        self::$findElementId = 0;
        
        self::$countElementsArray = [];
    }
}