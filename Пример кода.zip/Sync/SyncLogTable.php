<?php

namespace Ac\Forms\Forms\Data\Sync;

use Bitrix\Main\Entity\DataManager;
use Bitrix\Main\ORM\Fields\DatetimeField;
use Bitrix\Main\ORM\Fields\IntegerField;
use Bitrix\Main\ORM\Fields\StringField;
use Bitrix\Main\Type\DateTime;

class SyncLogTable extends DataManager
{
    public static function getTableName()
    {
        return 'uni_sync_error_log';
    }
    
    public static function getMap()
    {
        $map = [
            new IntegerField('ID', ['primary' => true, 'autocomplete' => true]),
            new IntegerField('FORM_ID', ['required' => true]),
            new StringField('SECTION_CODE', ['required' => true]),
            new StringField('DATA', ['required' => true, 'serialized' => true]),
            new StringField('ERROR_TEXT'),
            (new DatetimeField('CREATED_DATE'))
                ->configureRequired()
                ->configureDefaultValue(static function () {
                    return new DateTime();
                })
        ];
        return $map;
    }
}