<?php

namespace Ac\Forms\Forms\Data\Sync;

use Ac\Forms\Forms\Data\MainData;
use Bitrix\Iblock\ElementPropertyTable;
use Exception;

/**
 * Class StructureSync - учитывая настройки получает данные текущей пустой структуры и данные, которые нужно изменить/удалить/добавить в наполненных данных структуры, а также получает эти данные и производит изменения
 * @package Ac\Forms\Forms\Data\Sync
 */
final class StructureSync
{
    public SyncOptions $options;
    public string $error;
    public int $formId;
    public string $sectionCode;
    private ?int $sectionPropertyId;
    
    private int $currentParsingLevel = 0;
    private array $currentParentElement = [];
    
    //Исходные не изменяемые данные структуры раздела по элементам
    private array $elementSectionData = [];
    private array $elementTableId2formTableIdConnector = [];
    //Изменённые данные структуры раздела по элементам
    public array $changedElementSectionData = [];
    public array $isFormElementChanged = [];
    
    //Возможно не используются
    public array $formElementPartsUpdated = [];
    public array $formElementPartsCreated = [];
    public array $formElementPartsDeleted = [];
    
    //Готовые блоки для изменения, вставки исходя из изменённой схемы, парсятся из новой схемы.
    public array $emptyUpdateSchemaParts = [];
    public array $emptyCreateSchemaParts = [];
    public array $emptyCreateBlocksSchemaParts = [];
    
    //Для ресортировки используется лишь последовательность элементов.
    public array $resortedSchemaParts = [];
    
    //TODO: В fieldHeader vlue может содержать дополнительную струтуру, и её скорее нельзя так просто удалять, как value
    //fields 'groups', 'items' are deprecated !
    //Поля, которые не изменяются при апдейте
    public const UPDATE_UNSET_FIELDS = ['groups', 'items', 'fields', 'elementId', 'fieldHeader'];
    
    //Поля, содержащие блоки внутри себя
    public const TREE_PROCEED_FIELDS = ['groups', 'items', 'fields', 'fieldDefault', 'fieldHeader'];
    
    private bool $debug = false;
    
    public function __construct($formId, $sectionCode, SyncOptions $options)
    {
        $this->formId = $formId;
        $this->sectionCode = $sectionCode;
        $this->options = $options;
        if ($this->options->isAnyChange || $this->options->syncAllways) {
            $this->getSchemaPropertyValues();
        }
        if ($this->options->isUseEmptySchema) {
            $this->getEmptySchemaParts($this->options->structure ?: []);
        }
    }
    
    public static function getInstanceByForm(int $formId, string $sectionCode): StructureSync
    {
        $options = SyncOptions::getInstanceByFormAndSection($formId, $sectionCode);
        return new self($formId, $sectionCode, $options);
    }
    
    private function getSchemaPropertyValues(): void
    {
        if (!$this->sectionPropertyId = MainData::getSectionPropertyId($this->formId, $this->sectionCode)) {
            throw new Exception('Свойства для получения данных раздела ' . $this->sectionCode . ' формы ' . $this->formId . ' не существует');
        }
        $data = ElementPropertyTable::query()
            ->setFilter(['IBLOCK_PROPERTY_ID' => $this->sectionPropertyId, "IBLOCK_ELEMENT_ID" => $this->options->syncElementIds])
            ->setSelect(['ELEMENT_ID' => 'IBLOCK_ELEMENT_ID', 'VALUE' => 'VALUE', 'ID' => 'ID'])
            ->fetchAll();

        foreach ($data as $datum) {
            $this->elementTableId2formTableIdConnector[$datum['ELEMENT_ID']] = $datum['ID'];
            $this->elementSectionData[$datum['ELEMENT_ID']] = unserialize($datum['VALUE']);
        }
        
        //Заполнение ещё ни разу не добавленных свойств
        $this->fillEmptyElementsWithStructure();
        
        $this->changedElementSectionData = $this->elementSectionData;
    }
    
    /** По каким-то причинам свойство не добавлено, скорее всего это связано с восстановлением БД. Нужно поотслеживать. */
    private function fillEmptyElementsWithStructure(): void
    {
        $notFilledProperties = array_diff($this->options->syncElementIds, array_keys($this->elementSectionData));
        foreach ($notFilledProperties as $elementId) {
            //TODO: Всё проверить, сделать исключение
            $this->elementTableId2formTableIdConnector[$elementId] = $this->getNewPropertyTableId($elementId);
            $this->elementSectionData[$elementId] = [];
        }
    }
    
    /**
     * #По каким-то причинам свойство раздела не было создано, надо его пересоздать
     * @param int $elementId
     * @return int
     */
    private function getNewPropertyTableId(int $elementId): int
    {
        $dbResult = ElementPropertyTable::add([
            'IBLOCK_PROPERTY_ID' => $this->sectionPropertyId,
            'IBLOCK_ELEMENT_ID' => $elementId,
            'VALUE' => '',
            'VALUE_TYPE' => 'text',
        ]);
        return $dbResult->GetID() ?: 0;
    }
    
    /**
     * Сбор частей из пустой структуры по elementId для дальнейшего изменения
     * @param $parseData
     */
    private function getEmptySchemaParts(array $parseData)
    {
        if ($elementId = (int)$parseData['elementId']) {
            
            //Блоки на изменение
            $this->createUpdatedSchemaPart($elementId, $parseData);
    
            //Блоки на изменение
            $this->createResortedSchemaPart($elementId, $parseData);
            
            //Блоки на создание
            if ($this->createCreatedSchemaPart($elementId, $parseData)) {
                return;
            }
        }
    
        $this->currentParsingLevel++;
    
        foreach ($parseData as $datumKey => $datum) {

            if (is_array($datum)) {
                
                //Данные для получения исходного родительского элемента с elementId
                if (!empty($datum) && in_array($datumKey, self::TREE_PROCEED_FIELDS) && $elementId) {
                    $this->currentParentElement[$this->currentParsingLevel] = [
                        'elementId' => $elementId,
                        'field' => $datumKey
                    ];
                }
                $this->getEmptySchemaParts($datum);
                unset($this->currentParentElement[$this->currentParsingLevel]);
            }
        }
        
        $this->currentParsingLevel--;
    }
    
    private function createUpdatedSchemaPart(int $elementId, array $parseData): void
    {
        if (in_array($elementId, $this->options->updated)) {
            foreach (self::UPDATE_UNSET_FIELDS as $unsetField) {
                unset($parseData[$unsetField]);
            }
            
            if (array_key_exists('value', $parseData) && (!is_array($parseData['value']) || isset($parseData['value']['id']))) {
                unset($parseData['value']);
            }
            
            $this->emptyUpdateSchemaParts[$elementId] = $parseData;
        }
    }
    
    //Т.к. ещё нет информации об синхронизируемом элементе, получаем лишь информацию о последовательности сортируемых блоков
    private function createResortedSchemaPart(int $elementId, array $parseData): void
    {
        if (in_array($elementId, $this->options->resorted) && !empty($parseData['fields'])) {
            $this->resortedSchemaParts[$elementId] = array_column($parseData['fields'], 'elementId');
            
            //На тот случай, елси есть элементы с отсутствующим elementId, при создании через бэк
            //В этом случае пересортировка может пойти как угодно не по плану - поэтому исключаем этот случай, можно реализовать в дальнейшем
            if (count($this->resortedSchemaParts[$elementId]) !== count($parseData['fields'])) {
                unset($this->resortedSchemaParts[$elementId]);
            }
        }
    }
    
    private function createCreatedSchemaPart(int $elementId, array $parseData): bool
    {
        //var_dump($elementId, $this->currentParsingLevel, $this->currentParentElement);
        $previousParsingLevel = $this->currentParsingLevel - 1;
        $previousParsingElementData = $this->currentParentElement[$previousParsingLevel];
    
        //Если текущий элемент один из создаваемых и у элемента родителя также присутствует elementId и field (item и т.п.)
        if (in_array($elementId, $this->options->created)
            && ($parentFieldName = $previousParsingElementData['field'])
            && ($parentElementId = $previousParsingElementData['elementId'])
        ) {
            //Создаётся основа данных добавляемого элемента
            if (!isset($this->emptyCreateSchemaParts[$parentElementId][$parentFieldName])) {
                $this->emptyCreateSchemaParts[$parentElementId][$parentFieldName] = [];
            }
            //Добавляемых значений может быть несколько, поэтому собираются поочередно
            $this->emptyCreateSchemaParts[$parentElementId][$parentFieldName][] = $parseData;
            
            //Если данный блок создаётся, всё внутри него также создаётся с нуля и попадает в values, парсить его дальше не нужно и вообще нельзя.
            return true;
        }
    
        //Отдельное условие для верхнего уровня блоков
        if (in_array($elementId, $this->options->created)
            && ($parseData['fieldType'] === 'block')
            && $parseData['elementId']
        ) {
            $this->emptyCreateBlocksSchemaParts[$parseData['elementId']] = $parseData;
            return true;
        }
        
        return false;
    }
    
    public function save(): bool
    {
        foreach ($this->changedElementSectionData as $formElementId => $newSectionData) {
            if ($this->isFormElementChanged[$formElementId]) {
                
                if ($this->debug) {
                    echo "<b>Изменяем $formElementId</b><br>";
                    continue;
                }
                if (!$value = serialize($newSectionData)) {
                    $this->error = "Не удалось создать новые данне структуры для сохранения в элементе $formElementId";
                    return false;
                }
                if (!isset($this->elementTableId2formTableIdConnector[$formElementId])) {
                    throw new Exception('Не верный сценарий, создание свойства элемента, должно было быть скопировано из структуры');
                }
    
                $result = ElementPropertyTable::update($this->elementTableId2formTableIdConnector[$formElementId], [
                    'VALUE' => $value
                ]);
                if (!$result->isSuccess()) {
                    $this->error = implode(', ', $result->getErrorMessages());
                    return false;
                }
            }
        }
        return true;
    }
}