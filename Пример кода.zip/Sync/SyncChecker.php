<?php

namespace Ac\Forms\Forms\Data\Sync;

use Ac\Forms\Forms\Inspector\FormHandler;
use Ac\Forms\Forms\Inspector\SectionHandler;

/**
 * Class SyncChecker - для дополнительных проверок синхронизации. Наличие изменений, соответствие времени сохраняемой структуры.
 * @package Ac\Forms\Forms\Data\Sync
 */
final class SyncChecker
{
    public const MIN_STRUCTURE_RESAVE_SECONDS = 10;
    public const STRUCTURE_UPDATED_TIME_FIELD = 'structure-updated-time';
    
    /**
     * Проверка на наличие изменений новой структуры раздела
     * @param array $newStructure
     * @return bool
     */
    public static function isNewStructureHasChanges(array $newStructure): bool
    {
        return (new SyncOptions($newStructure))->isAnyChange;
    }
    
    /**
     * Добавление информации о времени текущего изменения
     * @param $structure
     */
    public static function setCurrentTimeInformation(array &$structure): void
    {
        $structure[self::STRUCTURE_UPDATED_TIME_FIELD] = time();
    }
    
    public static function getCurentTimeInformation(array $structure): int
    {
        return $structure[self::STRUCTURE_UPDATED_TIME_FIELD] ?: 0;
    }
    
    /**
     * Нельзя синхронизировать струтуру слишком часто, этот метод как раз призван ограничить этот момент
     * @param int $formId
     * @param string $sectionCode
     * @return bool
     */
    public static function isResaveTime(int $formId, string $sectionCode): bool
    {
        $newTime = time();
        $oldTime = self::getSectionUpdateTime($formId, $sectionCode);
        return !$oldTime || (($newTime - $oldTime) > self::MIN_STRUCTURE_RESAVE_SECONDS);
    }
    
    /**
     * Получение последнего времени сохранения структуры
     * @param int $formId
     * @param string $sectionCode
     * @return int
     */
    public static function getSectionUpdateTime(int $formId, string $sectionCode): int
    {
        return self::getCurentTimeInformation(SectionHandler::getStructure($formId, $sectionCode));
    }
    
    /**
     * Метод для заполненных данных, проверяет возможно ли сохранять эти данные, или структура раздела уже изменилась
     * Используется только при сохранении данных с фронта, если данных о времени используемой структуры с фронта нет то метод разрешает сохранение
     * @param int $formId
     * @param string $sectionCode
     * @param array $formData
     * @return bool
     */
    public static function isSectionDataSavePossible(int $formId, string $sectionCode, array $formData): bool
    {
        if (!$structureTime = self::getSectionUpdateTime($formId, $sectionCode)) {
            return true;
        }
        $currentTime = self::getCurentTimeInformation($formData);
        return !$currentTime || ($currentTime === $structureTime);
    }
    
    public static function logErrorSync(int $formId, string $sectionCode, array $newStructure, string $errorText = ''): void
    {
        FormHandler::createClassTableIfNotExists(SyncLogTable::class);
        SyncLogTable::add([
            'FORM_ID' => $formId ?: 0,
            'SECTION_CODE' => $sectionCode ?: '',
            'DATA' => $newStructure ?: [],
            'ERROR_TEXT' => $errorText ?: ''
        ]);
    }
    
}