<?php

namespace Ac\Forms\Forms\Inspector;

use Ac\Forms\Forms\Inspector\Presets\Main as Preset;
use Ac\Forms\Forms\Inspector\Presets\Users;
use Ac\Forms\Orm\Tables\UniFormListTable;
use Ac\Forms\Orm\Tables\UniFormSectionsTable;
use Bitrix\Iblock\ElementTable;
use Bitrix\Iblock\IblockTable;
use Bitrix\Main\Application;
use Bitrix\Main\ArgumentException;
use Bitrix\Main\Entity\Base;
use Bitrix\Main\Loader;
use Bitrix\Main\ObjectPropertyException;
use Bitrix\Main\ORM\Fields\StringField;
use Bitrix\Main\SystemException;
use Exception;

final class FormDeleter
{
    static int $formId;
    
    public static function delete(int $formId)
    {
        if (\Environment::isProdEnv()) {
            die;
        }
        
        self::$formId = $formId;
        
        global $DB;
        $DB->StartTransaction();
        if (self::deleteElements() && self::deleteIblock() && self::deleteSections() && self::deleteForm() && self::deleteVersionTables()) {
            $DB->Commit();
            return true;
        }
        $DB->Rollback();
        return false;
    }
    
    private static function deleteElements(): bool
    {
        if ($elementIds = array_column(\Ac\Forms\Forms\Inspector\FormHandler::getElements(self::$formId), 'ID')) {
            foreach ($elementIds as $elementId) {
                if (!\CIBlockElement::Delete($elementId)) {
                    return false;
                }
            }
        }
        return true;
    }
    
    private static function deleteIblock(): bool
    {
        if ($iblockId = \Ac\Forms\Forms\Inspector\FormHandler::getIblockIdByFormId(self::$formId)) {
            return \CIBlock::Delete($iblockId);
        }
        return false;
    }
    
    private static function deleteSections(): bool
    {
        global $DB;
        $DB->Query("DELETE FROM `" . UniFormSectionsTable::getTableName() . '` WHERE UNIFORM_ID = ' . self::$formId);
        return true;
    }
    
    private static function deleteForm(): bool
    {
        global $DB;
        $DB->Query("DELETE FROM `uni_form_presets` WHERE UNIFORM_ID = " . self::$formId);
        return (UniFormListTable::delete(self::$formId))->isSuccess();
    }
    
    private static function deleteVersionTables(): bool
    {
        $obj = new \Ac\Forms\Versions\VersionDeleter(self::$formId);
        global $DB;
        $DB->Query('DROP TABLE IF EXISTS ' . $obj->versionHistoryClass::getTableName());
        $DB->Query('DROP TABLE IF EXISTS ' . $obj->versionClass::getTableName());
        return true;
    }
}